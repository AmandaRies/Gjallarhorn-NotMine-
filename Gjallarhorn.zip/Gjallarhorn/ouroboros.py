import urllib

import os

x = 1

while x > 0:

    for y in range(0, 23001):

        def download_web_image(url):

            name = str(y) + ".jpg"

            urllib.urlretrieve(url, name)

        download_web_image("https://i.redditmedia.com/5gb1GWuQLrHV3hgUA_6lpeSfbr4YWwInmIHLuZ9Zhzc.jpg?w=704&s=e3d57c6f9e6a700dd691fd2221c8a97b")

    for z in range(0, 23001):

        file = str(z) + ".jpg"

        os.remove(file)