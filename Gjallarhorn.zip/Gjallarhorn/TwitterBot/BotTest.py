import tweepy
import sched, time
import gspread
from oauth2client.service_account import ServiceAccountCredentials

auth = tweepy.OAuthHandler("6dA7bhsWf9LPVAyynmjboZmum", "DvK68WconFaREDqFo3gqRp0riRMkS8BWwTDuXkeEAotGWrIxu2")
auth.set_access_token("756634151642595329-VpIjuQa0L7gYsilE2UfIkWyvjZ21gkK", "B5yZRi5RZ3rITnRRxgVQXJXDSubaYmTy9pGrRNcVcSrpP")

api = tweepy.API(auth)
try:
    api.verify_credentials()
    print("Twitter Authentication OK")
except:
    print("Error during Twitter authentication")

scope = ['https://spreadsheets.google.com/feeds',
        'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('client_secret.json', scope)
client = gspread.authorize(creds)
sheet = client.open("test spreadsheet").sheet1

for tweet in sheet.col_values(1):
    print(tweet)

#sheet.update('B1', 'P')
'''
y = 0
for x in sheet.col_values(1):
    cell_str = 'B' + str(y + 1)
    print(column_A[y])
    if (column_B[y] == 'U'):
        sheet.update(cell_str, 'P')
        print(column_B[y])
    y += 1
'''
loop = sched.scheduler(time.time, time.sleep)
def program(sc):
    column_A = sheet.col_values(1)
    column_B = sheet.col_values(2)
    column_C = sheet.col_values(3)
    iteration = 0
    for B in column_B:
        cell_str = 'B' + str(iteration + 1)
        if (B == 'U'):
            tweet = str(column_C[iteration]) + ' ' + str(column_A[iteration])
            print(tweet)
            api.update_status(tweet)
            sheet.update(cell_str, 'P')
            break
        iteration += 1
    #number_string = "Testing Tweepy API Twitter Bot: " + str(number)
    #api.update_status(number_string)
    loop.enter(60, 1, program, (sc,))

loop.enter(60, 1, program, (loop,))
loop.run()
