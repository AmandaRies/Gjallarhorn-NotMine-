import gspread
import tweepy
import requests
import shutil
from oauth2client.service_account import ServiceAccountCredentials

auth = tweepy.OAuthHandler("6dA7bhsWf9LPVAyynmjboZmum", "DvK68WconFaREDqFo3gqRp0riRMkS8BWwTDuXkeEAotGWrIxu2")
auth.set_access_token("756634151642595329-VpIjuQa0L7gYsilE2UfIkWyvjZ21gkK", "B5yZRi5RZ3rITnRRxgVQXJXDSubaYmTy9pGrRNcVcSrpP")

api = tweepy.API(auth)
try:
    api.verify_credentials()
    print("Twitter Authentication Complete")
except:
    print("Twitter Authentication Failed")
    exit()

scope = ['https://spreadsheets.google.com/feeds',
         'https://www.googleapis.com/auth/drive']
creds = ServiceAccountCredentials.from_json_keyfile_name('client_secret.json', scope)
client = gspread.authorize(creds)
sheet = client.open("Police Brutality").sheet1
print("Google Authentication Complete")

#print(sheet.col_values(1))

tweet_ids = []
for tweet in sheet.col_values(1):
    print(tweet.split('/')[-1])
    tweet_ids.append(tweet.split('/')[-1])
print(tweet_ids)

for id in tweet_ids:
    try:
        tweet = api.get_status(id, tweet_mode='extended')
        if 'media' in tweet.extended_entities:
            for image in tweet.extended_entities['media']:
                try:
                    for x in image['video_info']['variants']:
                        if x['content_type'] == 'video/mp4':
                            if x['bitrate'] == 2176000 or x['bitrate'] == 0:
                                print(x['url'])
                                r = requests.get(x['url'], allow_redirects=True)
                                file_name = tweet.id_str + '.mp4'
                                open(file_name, 'wb').write(r.content)
                                directory_from = 'C:/Users/Adam/PycharmProjects/PoliceBrutalityBot/' + file_name
                                directory_to = 'C:/Users/Adam/Desktop/database/Personal Database/' + file_name
                                shutil.move(directory_from, directory_to)
                except:
                    print(image['media_url'])
                    r = requests.get(image['media_url'], allow_redirects=True)
                    file_name = tweet.id_str + '.jpg'
                    open(file_name, 'wb').write(r.content)
                    directory_from = 'C:/Users/Adam/PycharmProjects/PoliceBrutalityBot/' + file_name
                    directory_to = 'C:/Users/Adam/Desktop/database/Personal Database/' + file_name
                    shutil.move(directory_from, directory_to)
    except:
        print('No Media Available')

print('Download Complete')