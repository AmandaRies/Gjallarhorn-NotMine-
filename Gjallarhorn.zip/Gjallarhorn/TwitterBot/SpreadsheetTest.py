import xlrd
workbook = xlrd.open_workbook('C:/Users/Adam/Desktop/Jason Miller Database/GeorgeFloyd Protest - police brutality videos on Twitter.xlsx')
worksheet = workbook.sheet_by_name('greg_doucette thread')
num_rows = worksheet.nrows - 1
curr_row = 7
while curr_row < num_rows:
        curr_row += 1
        row = worksheet.row(curr_row)
        current_link = row[3].value
        current_link_check = current_link[0:20]
        if (current_link_check == 'https://twitter.com/'):
                print(row[3].value)