import tweepy
import requests
import shutil

auth = tweepy.OAuthHandler("6dA7bhsWf9LPVAyynmjboZmum", "DvK68WconFaREDqFo3gqRp0riRMkS8BWwTDuXkeEAotGWrIxu2")
auth.set_access_token("756634151642595329-VpIjuQa0L7gYsilE2UfIkWyvjZ21gkK", "B5yZRi5RZ3rITnRRxgVQXJXDSubaYmTy9pGrRNcVcSrpP")

api = tweepy.API(auth)
try:
    api.verify_credentials()
    print("Authentication OK")
except:
    print("Error during authentication")

#api.update_status("Testing Tweepy API for Twitter.")
'''
for tweet in api.search(q="#StopExecutionsInIran", count=100, include_entities=True):
    if 'media' in tweet.entities:
        #print(f"{tweet.user.name}:{tweet.text}")
        for image in tweet.entities['media']:
            print(image['media_url'])
'''

tweets = ['https://twitter.com/AdamMartinTech/status/1281986485147795456', 'https://twitter.com/AdamMartinTech/status/1278092153223286787', 'https://twitter.com/supplierofmemes/status/1283847299760889857', 'https://twitter.com/greg_doucette/status/1283894982529744896', 'https://twitter.com/greg_doucette/status/1267295157885505537', 'https://twitter.com/greg_doucette/status/1267597140819415040?s=20', 'https://twitter.com/stribrooks/status/1266186985041022976']
tweet_ids = []
for tweet in tweets:
    print(tweet.split('/')[-1])
    #print(api.get_status(tweet.split('/')[-1], tweet_mode='extended'))
    tweet_ids.append(tweet.split('/')[-1])
print(tweet_ids)

for id in tweet_ids:
    try:
        tweet = api.get_status(id, tweet_mode='extended')
        if 'media' in tweet.extended_entities:
            for image in tweet.extended_entities['media']:
                try:
                    for x in image['video_info']['variants']:
                        if x['content_type'] == 'video/mp4':
                            if x['bitrate'] == 2176000 or x['bitrate'] == 0:
                                print(x['url'])
                                r = requests.get(x['url'], allow_redirects=True)
                                file_name = tweet.id_str + '.mp4'
                                open(file_name, 'wb').write(r.content)
                                directory_from = 'C:/Users/Adam/PycharmProjects/PoliceBrutalityBot/' + file_name
                                directory_to = 'C:/Users/Adam/Desktop/LibraryTest/' + file_name
                                shutil.move(directory_from, directory_to)
                except:
                    print(image['media_url'])
                    r = requests.get(image['media_url'], allow_redirects=True)
                    file_name = tweet.id_str + '.jpg'
                    open(file_name, 'wb').write(r.content)
                    directory_from = 'C:/Users/Adam/PycharmProjects/PoliceBrutalityBot/' + file_name
                    directory_to = 'C:/Users/Adam/Desktop/LibraryTest/' + file_name
                    shutil.move(directory_from, directory_to)
    except:
        print('No Media Available')

print('Download Complete')